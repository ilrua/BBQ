﻿/*
载入器 By Redmaple(ilrua)
载入器版本 0.0.2
*/
$(document).ready(function(){ 
    //网页加载完成，防止出现没有面板的问题
console.log('%c ','background-image:url("https://ae01.alicdn.com/kf/Ue8a48f388dce4430a0a1ed607bb4f7fdt.jpg");background-size:120% 120%;background-repeat:no-repeat;background-position:center center;line-height:60px;padding:30px 82px;');
//上面是宣传图片
chkupd()

function chkupd(){
var bbqver = 001
    //版本号001
    //更新
    //用法update(varb)
    var url = "https://ilrua.github.io/ilrua/bbq/info.json"//更新地址
            var request = new XMLHttpRequest();
            request.open("get", url);/*设置请求方法与路径*/
            request.send(null);/*不发送数据到服务器*/
            request.onload = function () {/*XHR对象获取到返回信息后执行*/
                if (request.status == 200) {/*返回状态为200，即为数据获取成功*/
                    var json = JSON.parse(request.responseText);
                    for(var i=0;i<json.length;i++){
                    	console.log(json[i].name);
                    }
                    var json = JSON.parse(request.responseText);
                    console.log("[UPDATE]已获取更新信息");
                }
                    //是的 因为特性 我们只能在这里进行判断。
                    var version = json.version
                    var info = json.info
                    var website = json.website
                    var locver=version.replace(".","");
                    if(bbqver < locver){
                        console.log("[CHK]有新的BBQ载入器更新")
                        console.log("[CHK]当前版本" + bbqver)
                        console.log("[CHK]新版本: " + version)
                        console.log("[CHK]载入器更新内容")
                        console.log(info)
                        console.log("[CHK]下载地址: " + website)
                    } else {
                        console.log("[CHK]您的BBQ载入器是最新的。请保持")
                        console.log("[CHK]当前版本" + bbqver)
                        console.log("[CHK]载入器更新内容")
                        console.log(info)
                        console.log("[CHK]下载地址: " + website)
                    }
            }
    
}

retry()

function retry(){
    var website = "https://ilrua.github.io/ilrua/bbq/bbq.js"//发布版直链
    var head = document.getElementsByTagName("head") //找到头
    var loadstyle = '<script type="text/javascript" src="'+website+'"></script>'
    $(head).append(loadstyle)
    console.log("[BOOT]已载入BBQ云，如未加载，请键入retry()")
}
});


function retry(){
    var website = "https://ilrua.github.io/ilrua/bbq/bbq.js"//发布版直链
    var head = document.getElementsByTagName("head") //找到头
    var loadstyle = '<script type="text/javascript" src="'+website+'"></script>'
    $(head).append(loadstyle)
    console.log("[BOOT]已载入BBQ云，如未加载，请键入retry()")
}//再放一个是因为防止无法重试
